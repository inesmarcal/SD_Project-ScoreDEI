package com.example.beans;

public class AuthenticationInformation {
    private boolean isAuthenticated;
    private boolean isAdmin;

    public AuthenticationInformation(){
        this.isAdmin = false;
        this.isAuthenticated = false;
    }

    public boolean getIsAuthenticated(){
        return this.isAuthenticated;
    }

    public void setIsAuthenticated(boolean isAuthenticated){
        this.isAuthenticated = isAuthenticated;
    }

    public boolean getIsAdmin(){
        return this.isAdmin;
    }

    public void setIsAdmin(boolean isAdmin){
        this.isAdmin = isAdmin;
    }

}
